from conllup.exception.model_exception import ModelException
from conllup.exception.runtime_exception import RuntimeException
from conllup.model.argument import Argument
from conllup.model.column import Column
from conllup.model.frame import Frame
from conllup.model.metadata import Metadata
from conllup.model.predicate import Predicate
from conllup.model.token import Token
from conllup.model.tree import Tree
from conllup.conllup import parse, zip_parse

from json import JSONEncoder


def _default(self, obj):
    return getattr(obj.__class__, "to_json", _default.default)(obj)


_default.default = JSONEncoder().default
JSONEncoder.default = _default

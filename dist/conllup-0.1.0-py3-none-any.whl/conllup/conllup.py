import logging
from typing import TextIO, List, Iterator, Union
from conllup.model.tree import Tree
import itertools
from conllup.model.column import Column, ColumnType
from conllup.model.token import Token

logger = logging.getLogger('conllup.' + __name__)

DEFAULT_SEPARATOR = "="

def __process(buffer: str, columns: List[Column] = None, separator: str = DEFAULT_SEPARATOR) -> Tree:
    '''Converts input buffer with text in CoNLL-U Plus format into tree object

    :param buffer: input buffer with text
    :type buffer: str_
    :param columns: optional list with columns definition, defaults to None
    :type columns: List[Column]
    :return: parsed tree object
    :rtype: Tree
    '''
    tree = Tree(columns)
    first = True
    for line in buffer:
        if line.startswith('#'):
            line = line[1:]
            pos = line.find(separator)
            if pos >= 0:
                segments = [line[:pos], line[pos+1:]]
            else:
                segments = [line]
            metadata_name = segments[0].strip()
            if len(segments) >= 2:
                metadata_value = segments[1].strip()
            else:
                metadata_value = None

            if metadata_name == tree.get_columns_attribute():
                tree.set_columns_from_names(metadata_value.split(' '))
            else:
                tree.add_metadata(metadata_name, metadata_value)
        else:
            segments = line.split('\t')
            if first:
                names = tree.get_column_names()
                frames_column = tree.get_column_by_type(ColumnType.UP_FRAME)
                if frames_column:
                    names_len = len(names)
                    diff = len(segments) - names_len
                    if diff >= 0:
                        names = names[0:names_len - 1]
                        for i in range(0, diff + 1):
                            names.append(ColumnType.UP_FRAME.value + str(i+1))
                    tree.set_columns_from_names(names)
                first = False
            token_name = segments[0]
            token = tree.add_token(token_name)
            for i, name in enumerate(names):
                if i < len(segments):
                    token.set_attribute(name, segments[i])
    tree.parse_frames()
    return tree


def parse(data: Union[str, TextIO], columns: List[Column] = None, separator: str = DEFAULT_SEPARATOR) -> Iterator[Tree]:
    '''Parses input string or file with several CoNLL-U Plus sentences and returns iterator with each single token tree

    :param data: input string or file to be parsed
    :type data: Union[str, TextIO]
    :param columns: optional list with columns definition, defaults to None
    :type columns: List[Column], optional
    :yield: each single tree
    :rtype: Iterator[Tree]
    '''
    buffer: List[str] = []
    if type(data) is str:
        data = data.split("\n")
    for line in data:
        line = line.strip()
        if len(line) == 0:
            if len(buffer) > 0:
                t = __process(buffer, columns, separator)
                if columns is None:
                    columns = t.get_columns()
                yield (t)
                buffer = []
        else:
            buffer.append(line)
    if len(buffer) > 0:
        t = __process(buffer, columns, separator)
        if columns is None:
            columns = t.get_columns()
        yield (t)

def zip_parse(file1: TextIO, file2: TextIO) -> Iterator[Tree]:
    '''Parses two parallel files with corresponding sentences and returns iterator with two corresponding token trees

    :param file1: the first input file to be parsed
    :type file1: TextIO
    :param file2: the second input file to be parsed
    :type file2: TextIO
    :yield: pair of token trees
    :rtype: Iterator[Tree]
    '''    
    full1 = []
    full2 = []
    buffer1 = []
    buffer2 = []
    columns1 = None
    columns2 = None
    for line1, line2 in itertools.zip_longest(file1, file2):
        if line1 is None:
            line1 = ""
        if line2 is None:
            line2 = ""
        line1 = line1.strip()
        line2 = line2.strip()
        if len(line1) > 0:
            buffer1.append(line1)
        else:
            full1.append(buffer1.copy())
            buffer1.clear()
        if len(line2) > 0:
            buffer2.append(line2)
        else:
            full2.append(buffer2.copy())
            buffer2.clear()
        l1 = len(full1)
        l2 = len(full2)
        l = min(l1, l2)
        if l > 0:
            for i in range(0, l):
                e1 = full1.pop(0)
                e2 = full2.pop(0)
                t1 = __process(e1, columns1, DEFAULT_SEPARATOR)
                t2 = __process(e2, columns2, DEFAULT_SEPARATOR)
                if columns1 is None:
                    columns1 = t1.get_columns()
                if columns2 is None:
                    columns2 = t2.get_columns()
                yield (t1, t2)

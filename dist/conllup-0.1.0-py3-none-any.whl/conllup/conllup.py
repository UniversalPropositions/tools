import logging
from typing import TextIO, List, Iterator, Union
from conllup.model.tree import Tree
import itertools
from conllup.model.column import ColumnType
from conllup.model.token import Token

logger = logging.getLogger('conllup.' + __name__)

def __process(buffer) -> Tree:
    tree = Tree()
    first = True
    for line in buffer:
        if line.startswith('#'):
            line = line[1:]
            segments = line.split('=')
            metadata_name = segments[0].strip()
            metadata_value = segments[1].strip()
            if metadata_name == tree.get_columns_attribute():
                tree.set_columns_from_names(metadata_value.split(' '))
            else:
                tree.add_metadata(metadata_name, metadata_value)
        else:
            segments = line.split('\t')
            if first:
                names = tree.get_column_names()
                names_len = len(names)
                last_name = names[names_len - 1]
                diff = len(segments) - names_len
                multi = last_name.endswith('*')
                if diff > 0 and multi == True: 
                    last_name = last_name[0:len(last_name) - 1]
                    names = names[0:names_len - 1]
                    for i in range(0, diff + 1):
                        names.append(last_name + str(i+1))
                tree.set_columns_from_names(names)
                first = False
            token_name = segments[0]
            token = tree.add_token(token_name)
            for i, name in enumerate(names):
                if i < len(segments):
                    #if segments[i].isdigit():
                    #    token.set_attribute(name, int(segments[i]))
                    #else:
                    token.set_attribute(name, segments[i])
    tree.parse_frames()

    return tree

def parse(data: Union[str, TextIO]) -> Iterator[Tree]:
    buffer: List[str] = []
    if type(data) is str:
        data = data.split("\n")
    
    for line in data:
        line = line.strip()
        if len(line) == 0:
            if len(buffer) > 0:
                yield __process(buffer)
                buffer = []
        else:
            buffer.append(line)
    if len(buffer) > 0:
        yield __process(buffer)

def zip_parse(file1: TextIO, file2: TextIO) -> Iterator[Tree]:
    buffer1_old: List[str] = []
    buffer1_new: List[str] = []
    buffer2_old: List[str] = []
    buffer2_new: List[str] = []
    yield1 = False
    yield2 = False
    for line in itertools.zip_longest(file1, file2):
        line1 = line[0]
        line2 = line[1]
        if line1 is None:
            yield1 = True
        else:
            line1 = line1.strip()
            if len(line1) == 0:
                yield1 = True
        if line2 is None:
            yield2 = True
        else:
            line2 = line2.strip()
            if len(line2) == 0:
                yield2 = True
        if not yield1 and not yield2:
            buffer1_old.append(line1)
            buffer2_old.append(line2)
        if yield1 and not yield2:
            if line1 is not None and len(line1) > 0:
                buffer1_new.append(line1)
            buffer2_old.append(line2)
        if not yield1 and yield2:
            buffer1_old.append(line1)
            if line2 is not None and len(line2) > 0:
                buffer2_new.append(line2)
        if yield1 and yield2:
            yield (__process(buffer1_old), __process(buffer2_old))
            yield1 = False
            yield2 = False
            buffer1_old = buffer1_new
            buffer2_old = buffer2_new
            buffer1_new.clear()
            buffer2_new.clear()
    if len(buffer1_old) > 0 or len(buffer2_old) > 0:
        yield (__process(buffer1_old), __process(buffer2_old))
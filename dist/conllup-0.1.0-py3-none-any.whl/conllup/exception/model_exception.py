'''
Exception thrown each time a problem with Tree model occurs
'''

class ModelException(Exception):
    pass

class ModelException(Exception):
    pass
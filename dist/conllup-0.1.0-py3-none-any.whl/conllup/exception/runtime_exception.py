class RuntimeException(Exception):
    pass
'''
Exception thrown each time any runtime problem with processing occurs
'''

class RuntimeException(Exception):
    pass

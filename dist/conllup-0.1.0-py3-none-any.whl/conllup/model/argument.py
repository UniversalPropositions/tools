class Argument:
    '''A class that represents SRL Argument.

    It stores argument name, argument head and the range for argument span.
    '''    

    def __init__(self, name: str, head: int = 0, start: int = 0, end: int = 0):
        '''Argument class contructor

        :param name: attribute name
        :type name: str
        :param head: argument head token, defaults to 0
        :type head: int, optional
        :param start: argument span start token, defaults to 0
        :type start: int, optional
        :param end: argument span end token, defaults to 0
        :type end: int, optional
        '''        
        self._name = name
        self._head = head
        self._start = start
        if start == 0:
            self._start = head
        else:
            self._start = start
        if end == 0:
            self._end = start
        else:
            self._end = end

    def get_name(self) -> str:
        '''Returns argument name

        :return: argument name
        :rtype: str
        '''        
        return self._name

    def get_head(self) -> int:
        '''Returns argument head token

        :return: argument head token
        :rtype: int
        '''        
        return self._head

    def get_start(self) -> int:
        '''Returns argument span start token

        :return: argument span start token
        :rtype: int
        '''  
        return self._start

    def get_end(self) -> int:
        '''Returns argument span end token

        :return: argument span end token
        :rtype: int
        '''  
        return self._end

    def set_name(self, name: str):
        '''Sets argument name

        :param end: argument name
        :type end: str
        '''   
        self._name = name

    def set_head(self, head: int):
        '''Sets argument head token

        :param head: argument head token
        :type head: int
        '''        
        self._head = head

    def set_start(self, start: int):
        '''Sets argument span start token

        :param start: argument span start token
        :type start: int
        '''        
        self._start = start

    def set_end(self, end: int):
        '''Sets argument span end token

        :param end: argument span end token
        :type end: int
        '''        
        self._end = end

    def to_json(self) -> dict:
        result = {
            "name": self._name,
            "head": self._head,
            "start": self._start,
            "end": self._end
        }
        return result
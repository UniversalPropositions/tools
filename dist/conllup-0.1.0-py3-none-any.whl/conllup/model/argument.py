import string


class Argument:

    def __init__(self, name: string, head: int = 0, start: int = 0, end: int = 0):
        self.name = name
        self.head = head
        self.start = start
        if start == 0:
            self.start = head
        else:
            self.start = start
        if end == 0:
            self.end = start
        else:
            self.end = end

    def get_name(self):
        return self.name

    def get_head(self):
        return self.head

    def get_start(self):
        return self.start
    
    def get_end(self):
        return self.end
        
    def set_head(self, head):
        self.head = head

    def set_name(self, name):
        self.name = name

    def set_head(self, head):
        self.head = head
        
    def set_start(self, start):
        self.start = start
    
    def set_end(self, end):
        self.end = end
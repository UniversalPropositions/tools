import string

'''
Entity class for SRL Arguments
'''
class Argument:

    def __init__(self, name: str, head: int = 0, start: int = 0, end: int = 0):
        self._name = name
        self._head = head
        self._start = start
        if start == 0:
            self._start = head
        else:
            self._start = start
        if end == 0:
            self._end = start
        else:
            self._end = end

    '''
    Variable getters and setters
    '''
    def get_name(self) -> str:
        return self._name

    def get_head(self) -> int:
        return self._head

    def get_start(self) -> int:
        return self._start

    def get_end(self) -> int:
        return self._end

    def set_head(self, head: int):
        self._head = head

    def set_name(self, name: str):
        self._name = name

    def set_start(self, start: int):
        self._start = start

    def set_end(self, end: int):
        self._end = end

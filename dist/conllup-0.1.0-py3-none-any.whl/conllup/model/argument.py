class Argument:
    '''A class that represents SRL Argument.

    It stores argument name, argument head and the range for argument span.
    '''    

    def __init__(self, name: str, head: str = None, start: str = None, end: str = None):
        '''Argument class contructor

        :param name: attribute name
        :type name: str
        :param head: argument head token, defaults to None
        :type head: str, optional
        :param start: argument span start token, defaults to None
        :type start: str, optional
        :param end: argument span end token, defaults to None
        :type end: str, optional
        '''        
        self._name = name
        self._head = head
        self._start = start
        if start is None:
            self._start = head
        else:
            self._start = start
        if end is None:
            self._end = start
        else:
            self._end = end

    def get_name(self) -> str:
        '''Returns argument name

        :return: argument name
        :rtype: str
        '''        
        return self._name

    def get_head(self) -> str:
        '''Returns argument head token

        :return: argument head token
        :rtype: str
        '''        
        return self._head

    def get_start(self) -> str:
        '''Returns argument span start token

        :return: argument span start token
        :rtype: str
        '''  
        return self._start

    def get_end(self) -> str:
        '''Returns argument span end token

        :return: argument span end token
        :rtype: str
        '''  
        return self._end

    def set_name(self, name: str):
        '''Sets argument name

        :param end: argument name
        :type end: str
        '''   
        self._name = name

    def set_head(self, head: str):
        '''Sets argument head token

        :param head: argument head token
        :type head: str
        '''        
        self._head = head

    def set_start(self, start: str):
        '''Sets argument span start token

        :param start: argument span start token
        :type start: str
        '''        
        self._start = start

    def set_end(self, end: str):
        '''Sets argument span end token

        :param end: argument span end token
        :type end: str
        '''        
        self._end = end

    def to_json(self) -> dict:
        result = {
            "name": self._name,
            "head": self._head,
            "start": self._start,
            "end": self._end
        }
        return result
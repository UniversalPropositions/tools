from enum import Enum


'''
Enum class with column types
'''
class ColumnType(Enum):
    ID = "ID"
    BASIC = None
    UP_PRED = "UP:PRED"
    UP_ARGHEADS = "UP:ARGHEADS"
    UP_ARGSPANS = "UP:ARGSPANS"

'''
Entity class for CoNLL-U Plus column, each token has exactly one value for each column
'''
class Column:

    def __init__(self, name: str, type: ColumnType = ColumnType.BASIC):
        self.name = name
        self.type = type

    def get_name(self) -> str:
        return self.name

    def get_type(self) -> ColumnType:
        return self.type

    def set_name(self, name: str):
        self.name = name
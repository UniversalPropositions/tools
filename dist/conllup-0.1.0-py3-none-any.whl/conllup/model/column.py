from enum import Enum

class ColumnType(Enum):
    ID = "ID"
    BASIC = None
    UP_PRED = "UP:PRED"
    UP_ARGHEADS = "UP:ARGHEADS"
    UP_ARGSPANS = "UP:ARGSPANS"

class Column:

    def __init__(self, name, type: ColumnType = ColumnType.BASIC):
        self.name = name
        self.type = type

    def get_name(self):
        return self.name

    def set_name(self, name):
        self.name = name

    def get_type(self):
        return self.type
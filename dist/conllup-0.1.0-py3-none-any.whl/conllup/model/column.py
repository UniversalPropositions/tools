from enum import Enum

class ColumnType(Enum):
    '''An enum class that represents possible column types used in CoNLL-U Plus definition

    It consists of name and value
    '''    
    ID = "ID"
    BASIC = None
    UP_PRED = "UP:PRED"
    UP_ARGHEADS = "UP:ARGHEADS"
    UP_ARGSPANS = "UP:ARGSPANS"
    UP_FLAG = "UP:FLAG"
    UP_FRAME = "UP:FRAME"

class Column:
    '''A class that represents CoNLL-U Plus column, each token in a given tree has exactly one value for each column.

    It stores name and type.
    '''   
    def __init__(self, name: str, type: ColumnType = ColumnType.BASIC):
        '''Column class contructor

        :param name: column name
        :type name: str
        :param type: column type, defaults to ColumnType.BASIC
        :type type: ColumnType, optional
        '''        
        self._name = name
        self._type = type

    def get_name(self) -> str:
        '''Returns column name

        :return: column name
        :rtype: str
        '''        
        return self._name

    def get_type(self) -> ColumnType:
        '''Returns column type

        :return: column type
        :rtype: ColumnType
        '''        
        return self._type

    def set_name(self, name: str):
        '''Sets column name

        :param name: column name
        :type name: str
        '''        
        self._name = name
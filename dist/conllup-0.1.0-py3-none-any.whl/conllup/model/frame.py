from typing import List
from conllup.model.predicate import Predicate
from conllup.model.argument import Argument

'''
Entity class for SRL frame
'''
class Frame:

    def __init__(self):
        self.predicate = {}
        self.arguments = []

    def get_predicate(self) -> Predicate:
        return self.predicate

    def get_arguments(self) -> List[Argument]:
        return self.arguments

    def set_predicate(self, predicate: Predicate):
        self.predicate = predicate

    def add_argument(self, argument: Argument):
        self.arguments.append(argument)
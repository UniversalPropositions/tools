from conllup.model.argument import Argument

class Frame:

    def __init__(self):
        self.predicate = {}
        self.arguments = []

    def set_predicate(self, predicate):
        self.predicate = predicate
    
    def add_argument(self, argument: Argument):
        self.arguments.append(argument)

    def get_predicate(self):
        return self.predicate

    def get_arguments(self):
        return self.arguments
from typing import List
from conllup.model.predicate import Predicate
from conllup.model.argument import Argument

class Frame:
    '''A class that represents CoNLL-U Plus SRL frame.

    It stores predicate and arguments.
    '''   
    def __init__(self):
        '''Frame class contructor

        '''        
        self._predicate = {}
        self._arguments = []

    def get_predicate(self) -> Predicate:
        '''Returns predicate object

        :return: predicate object
        :rtype: Predicate
        '''        
        return self._predicate

    def get_arguments(self) -> List[Argument]:
        '''Returns the list of argument objects

        :return: the list of arguments
        :rtype: List[Argument]
        '''        
        return self._arguments

    def set_predicate(self, predicate: Predicate):
        '''Sets predicate object

        :param predicate: predicate object
        :type predicate: Predicate
        '''        
        self._predicate = predicate

    def add_argument(self, argument: Argument):
        '''Adds new argument to the list of arguments

        :param argument: argument object
        :type argument: Argument
        '''        
        self._arguments.append(argument)
import json

class Metadata:
    '''A class that represents CoNLL-U Plus metadata that can be added to a tree

    It stores a value. Key is defined on the tree level.
    '''   
    def __init__(self):
        '''Metadata class contructor

        '''        
        self._value = None

    def get_value(self) -> str:
        '''Returns metadata value

        :return: metadata value
        :rtype: str
        '''        
        return self._value

    def set_value(self, value: str):
        '''Sets metadata value

        :param value: metadata value
        :type value: str
        '''        
        self._value = value

    def toJSON(self) -> dict:
        '''Converts metadata value to string, applies only to metadata value in json format

        :return: _description_
        :rtype: dict
        '''        
        return json.dumps(self._value)

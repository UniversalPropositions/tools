import json

'''
Entity class for Metadata that can be added to the Tree
'''
class Metadata:

    def __init__(self):
        self.value = None

    def get_value(self) -> str:
        return self.value

    def set_value(self, value: str):
        self.value = value

    def toJSON(self) -> dict:
        return json.dumps(self.value)

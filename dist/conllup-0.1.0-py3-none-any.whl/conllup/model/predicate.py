class Predicate:
    '''A class that represents CoNLL-U Plus SRL Predicate that can be assigned to a frame

    It stores token number and predicate sense.
    ''' 
    def __init__(self, sense: str, token: int):
        '''Predicate class contructor

        :param sense: predicate sense
        :type sense: str
        :param token: token number to which predicate is assigned
        :type token: int
        '''        
        self._token = token
        self._sense = sense

    def get_token(self) -> int:
        '''Returns token number to which predicate is assigned

        :return: token number
        :rtype: int
        '''        
        return self._token

    def get_sense(self) -> str:
        '''Returns predicate sense

        :return: predicate sense
        :rtype: str
        '''        
        return self._sense

    def set_token(self, token: int):
        '''Sets token number to which predicate is assigned

        :param token: token number
        :type token: int
        '''        
        self._token = token

    def set_sense(self, sense: str):
        '''Sets predicate sense

        :param sense: predicate sense
        :type sense: str
        '''        
        self._sense = sense

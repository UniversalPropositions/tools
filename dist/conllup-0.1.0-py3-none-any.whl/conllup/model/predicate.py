'''
Entity class for Predicate
'''
class Predicate:

    def __init__(self, sense: str, token: int):
        self.token = token
        self.sense = sense

    def get_token(self) -> int:
        return self.token

    def get_sense(self) -> str:
        return self.sense

    def set_token(self, token: int):
        self.token = token

    def set_sense(self, sense: str):
        self.sense = sense

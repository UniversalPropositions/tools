class Predicate:

    def __init__(self, sense, token: int):
        self.token = token
        self.sense = sense

    def get_token(self):
        return self.token

    def get_sense(self):
        return self.sense
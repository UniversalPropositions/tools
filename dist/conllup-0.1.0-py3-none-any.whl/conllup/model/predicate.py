class Predicate:

    def __init__(self, sense, token: int):
        self.token = token
        self.sense = sense

    def get_token(self):
        return self.token

    def get_sense(self):
        return self.sense

    def set_token(self, token):
        self.token = token
        
    def set_sense(self, sense):
        self.sense = sense
from typing import Union
from conllup.exception.model_exception import ModelException
from conllup.model.column import Column

EMPTY = '_'

class Token:
    '''A class that represents single token, tree consists of many tokens

    It stores token id, attributes with their values and has reference to parent tree object
    '''    
    def __init__(self, tree, id: str):
        '''Token class constructor

        :param tree: parent tree object
        :type tree: Tree object - type not defined to avoid circual dependencies
        :param id: token id
        :type id: str
        '''        
        self._id = id
        self._attributes = {}
        self._tree = tree
        for column in self._tree.get_column_names():
            self._attributes[column] = EMPTY

    def get_attribute(self, key: Union[str, Column]) -> str:
        '''Returns an attribute value for a given column name

        :param key: column
        :type key: Union[str, Column]
        :raises ModelException: _description_
        :return: attribute value
        :rtype: str
        '''        
        if type(key) is Column:
            key = key.get_name()
        if key in self._attributes:
            return self._attributes[key]
        else:
            raise ModelException(f'Attribute {key} does not exists')

    def get_empty() -> str:
        '''Returns an empty character that denotes empty value for a given token/column

        :return: empty character
        :rtype: str
        '''        
        return EMPTY

    def get_id(self) -> str:
        '''Returns unique token id

        :return: token id
        :rtype: str
        '''        
        return self._id

    def set_attribute(self, key: Union[str, Column], value: str):
        '''Sets value for a given column

        :param key: column name
        :type key: str
        :param value: column value
        :type value: str
        :raises ModelException: _description_
        '''        
        if key is None:
            return
        if type(key) is Column:
            key = key.get_name()
        if key in self._attributes:
            self._attributes[key] = value
        else:
            raise ModelException(
                f'Key {key} not available in definition. Possible keys: {self._attributes.keys()}')

from typing import Union
from conllup.exception.model_exception import ModelException
from conllup.model.column import Column

EMPTY = '_'

class Token:

    def __init__(self, tree, id):
        self.id = id
        self.attributes = {}
        self.tree = tree
        for column in self.tree.get_column_names():
            self.attributes[column] = EMPTY

    def get_attribute(self, key: Union[str, Column]):
        if type(key) is Column:
            key = key.get_name()
        return self.attributes[key]

    def set_attribute(self, key, value):
        if key is None:
            return
        if key in self.attributes:
            self.attributes[key] = value
        else:
            raise ModelException(f'Key {key} not available in definition. Possible keys: {self.attributes.keys()}')

    def get_empty():
        return EMPTY

    def get_id(self):
        return self.id
from typing import Union
from conllup.exception.model_exception import ModelException
from conllup.exception.runtime_exception import RuntimeException
from conllup.model.column import Column

EMPTY = '_'

'''
Entity class for Token, Tree object contains tokens
'''
class Token:

    def __init__(self, tree, id: str):
        self.id = id
        self.attributes = {}
        self.tree = tree
        for column in self.tree.get_column_names():
            self.attributes[column] = EMPTY

    def get_attribute(self, key: Union[str, Column]) -> str:
        if type(key) is Column:
            key = key.get_name()
        if key in self.attributes:
            return self.attributes[key]
        else:
            raise ModelException(f'Attribute {key} does not exists')

    def set_attribute(self, key: str, value: str):
        if key is None:
            return
        if key in self.attributes:
            self.attributes[key] = value
        else:
            raise ModelException(
                f'Key {key} not available in definition. Possible keys: {self.attributes.keys()}')

    def get_empty() -> str:
        return EMPTY

    def get_id(self) -> str:
        return self.id

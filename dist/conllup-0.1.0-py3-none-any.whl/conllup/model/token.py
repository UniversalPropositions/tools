from conllup.exception.model_exception import ModelException

EMPTY = '_'

class Token:

    def __init__(self, attributes):
        self.attributes = {}
        for attribute in attributes:
            self.attributes[attribute] = EMPTY

    def get_attribute(self, key):
        return self.attributes[key]

    def set_attribute(self, key, value):
        if key in self.attributes:
            self.attributes[key] = value
        else:
            raise ModelException(f'Key {key} not available in definition. Possible keys: {self.attributes.keys()}')
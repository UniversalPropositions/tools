import json
from typing import List
from conllup.model.token import Token
from conllup.model.metadata import Metadata
from conllup.exception.model_exception import ModelException

DEFINITION_ATTRIBUTE = "global.columns"
DEFAULT_DEFINITION = ["ID", "FORM", "LEMMA", "UPOS", "XPOS", "FEATS", "HEAD", "DEPREL", "DEPS", "MISC", "OPT*"]

class Tree():

    def __init__(self, definition: List[str] = None):
        self.metadata = {}
        self.set_definition(definition)
        self.tokens = {}
        metadata = self.create_metadata(DEFINITION_ATTRIBUTE)
        metadata.set_value(" ".join(self.definition))

    def get_conllup_type(self):
        return self.conllup_type

    def to_json(self):
        obj = {
            "metadata": {},
            "tokens": {}
        }
        for m in self.metadata:
            obj["metadata"][m] = self.get_metadata(m).get_value()
        for t in self.tokens:
            attributes = {}
            for d in self.definition:
                attributes[d] = self.tokens[t].get_attribute(d)
            obj["tokens"][t] = attributes
        return obj

    def get_definition_attribute(self):
        return DEFINITION_ATTRIBUTE

    def set_definition(self, definition):
        if definition is not None:
            self.definition = definition
        else:
            self.definition = DEFAULT_DEFINITION

    def get_definition(self):
        return self.definition

    def create_metadata(self, key):
        if key in self.metadata and key != DEFINITION_ATTRIBUTE:
            raise ModelException(f'Metadata {key} already created')
        self.metadata[key] = Metadata()
        return self.metadata[key]

    def get_metadata(self, key):
        if key not in self.metadata:
            raise ModelException(f'Metadata {key} does not exist')
        return self.metadata[key]

    def create_token(self, key):
        if key in self.tokens:
            raise ModelException(f'Token {key} already created')
        self.tokens[key] = Token(self.definition)
        return self.tokens[key]
    
    def get_token(self, key):
        if key not in self.tokens:
            raise ModelException(f'Token {key} does not exist')
        return self.tokens[key]

    def to_conllup(self) -> str:
        buffer: List[str] = []
        for m in self.metadata:
            buffer.append(f'# {m} = {self.get_metadata(m).get_value()}')
        for t in self.tokens:
            attributes = []
            for d in self.definition:
                attributes.append(self.tokens[t].get_attribute(d))
            buffer.append("\t".join(attributes))
        return "\n".join(buffer)
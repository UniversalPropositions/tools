from typing import List
from conllup.model.token import Token
from conllup.model.metadata import Metadata
from conllup.exception.model_exception import ModelException
from conllup.model.column import Column, ColumnType
from conllup.model.frame import Frame
from conllup.model.argument import Argument
from conllup.model.predicate import Predicate

COLUMNS_ATTRIBUTE = "global.columns"

COLUMNS_DEFAULT = [
    Column("ID"),
    Column("FORM"), 
    Column("LEMMA"),
    Column("UPOS"), 
    Column("XPOS"),
    Column("FEATS"),
    Column("HEAD"),
    Column("DEPREL"),
    Column("DEPS"),
    Column("MISC")
]

class Tree():
    '''A class that represents CoNLL-U Plus token tree object

    It stores columns definition, the list of metadata, the list of tokens and optionally the list of SRL frames
    ''' 
    def __init__(self, columns: List[Column] = None):
        '''_summary_

        _extended_summary_

        :param columns: _description_, defaults to None
        :type columns: List[Column], optional
        '''        
        if columns is None:
            self._columns = COLUMNS_DEFAULT
        else:
            self._columns = columns
        self._metadata = {}
        self._tokens = {}
        self._frames = []

    def set_columns(self, columns: List[Column]):
        '''_summary_

        _extended_summary_

        :param columns: _description_
        :type columns: List[Column]
        '''        
        self._columns = columns

    def set_columns_from_names(self, names: List[str]):
        '''_summary_

        _extended_summary_

        :param names: _description_
        :type names: List[str]
        '''        
        columns = []
        for name in names:
            type = self.get_type_from_name(name)
            columns.append(Column(name, type))
        self._columns = columns

    def get_type_from_name(self, name: str) -> ColumnType:
        '''_summary_

        _extended_summary_

        :param name: _description_
        :type name: str
        :return: _description_
        :rtype: ColumnType
        '''        
        for ct in ColumnType:
            if ct != ColumnType.BASIC:
                if ct.value in name:
                    return ct
        return ColumnType.BASIC

    def get_column_by_type(self, type: ColumnType) -> Column:
        '''_summary_

        _extended_summary_

        :param type: _description_
        :type type: ColumnType
        :return: _description_
        :rtype: Column
        '''        
        for c in self._columns:
            if c.get_type().name == type.name:
                return c
        return None
    
    def get_columns_by_type(self, type: ColumnType) -> List[Column]:
        '''_summary_

        _extended_summary_

        :param type: _description_
        :type type: ColumnType
        :return: _description_
        :rtype: Column
        '''        
        columns = []
        for c in self._columns:
            if c.get_type().name == type.name:
                columns.append(c)
        return columns

    def get_frames(self) -> List[Frame]:
        '''_summary_

        _extended_summary_

        :return: _description_
        :rtype: List[Frame]
        '''        
        return self._frames

    def add_frame(self, frame: Frame):
        '''_summary_

        _extended_summary_

        :param frame: _description_
        :type frame: Frame
        '''        
        self._frames.append(frame)

    def get_column_names(self) -> List[str]:
        '''_summary_

        _extended_summary_

        :return: _description_
        :rtype: List[str]
        '''        
        names = []
        for column in self._columns:
            names.append(column.get_name())
        return names

    def get_columns_attribute(self) -> str:
        '''_summary_

        _extended_summary_

        :return: _description_
        :rtype: str
        '''        
        return COLUMNS_ATTRIBUTE

    def add_metadata(self, key: str, value = None) -> Metadata:
        '''_summary_

        _extended_summary_

        :param key: _description_
        :type key: str
        :param value: _description_, defaults to None
        :type value: _type_, optional
        :raises ModelException: _description_
        :return: _description_
        :rtype: Metadata
        '''        
        if key in self._metadata and key != self.get_columns_attribute():
            raise ModelException(f'Metadata {key} already exists')
        self._metadata[key] = Metadata()
        if value is not None:
            self._metadata[key].set_value(value)
        return self._metadata[key]

    def get_metadata(self, key: str = None) -> Metadata:
        '''_summary_

        _extended_summary_

        :param key: _description_, defaults to None
        :type key: str, optional
        :raises ModelException: _description_
        :return: _description_
        :rtype: Metadata
        '''        
        if key is None:
            return self._metadata
        else:
            if key not in self._metadata:
                raise ModelException(f'Metadata {key} does not exist')
            return self._metadata[key]

    def add_token(self, key: str) -> Token:
        '''_summary_

        _extended_summary_

        :param key: _description_
        :type key: str
        :raises ModelException: _description_
        :return: _description_
        :rtype: Token
        '''        
        key = str(key)
        if key in self._tokens:
            raise ModelException(f'Token {key} already created')
        self._tokens[key] = Token(self, key)
        column = self.get_column_by_type(ColumnType.ID)
        if column is not None:
            self._tokens[key].set_attribute(column.get_name(), key)
        return self._tokens[key]
    
    def get_token(self, key: str) -> Token:
        '''_summary_

        _extended_summary_

        :param key: _description_
        :type key: str
        :raises ModelException: _description_
        :return: _description_
        :rtype: Token
        '''        
        key = str(key)
        if key not in self._tokens:
            raise ModelException(f'Token {key} does not exist')
        return self._tokens[key]

    def get_tokens(self) -> List[Token]:
        '''_summary_

        _extended_summary_

        :return: _description_
        :rtype: List[Token]
        '''        
        arr = []
        for token in self._tokens:
            arr.append(self._tokens[token])
        return arr

    def __parse_dep(self, text: str) -> List[Argument]:
        '''_summary_

        _extended_summary_

        :param text: _description_
        :type text: str
        :raises ModelException: _description_
        :return: _description_
        :rtype: List[Argument]
        '''        
        #AM-DIS:1|A1:5|AM-TMP:12|A2:14
        arguments = []
        try:
            segments = text.split("|")
            for segment in segments:
                subsegments = segment.split(":")
                arg = subsegments[0]
                pos = subsegments[1]
                arguments.append(Argument(arg, head = pos))
        except:
            raise ModelException(f'Incorrect UP:DEPARGS definition: {text}')
        return arguments

    def __parse_span(self, text: str) -> List[Argument]:
        '''_summary_

        _extended_summary_

        :param text: _description_
        :type text: str
        :raises ModelException: _description_
        :return: _description_
        :rtype: List[Argument]
        '''        
        #AM-DIS:1-3|A1:5-9|AM-TMP:12-12|A2:14-15
        arguments = []
        try:
            segments = text.split("|")
            for segment in segments:
                subsegments = segment.split(":")
                arg = subsegments[0]
                pos_segments = subsegments[1].split("-")
                arguments.append(Argument(arg, start = pos_segments[0], end = pos_segments[1]))
        except:
            raise ModelException(f'Incorrect UP:SPANARGS definition: {text}')
        return arguments

    def __to_dep(self, frame: Frame) -> str:
        '''_summary_

        _extended_summary_

        :param frame: _description_
        :type frame: Frame
        :return: _description_
        :rtype: str
        '''        
        #AM-DIS:1|A1:3|AM-NEG:5|A2:6
        tokens = []
        if len(frame.get_arguments()) == 0:
            return "_"
        else:
            for arg in frame.get_arguments():
                name = arg.get_name()
                pos = arg.get_head()
                tokens.append(f'{name}:{pos}')
            return '|'.join(tokens)

    def __to_span(self, frame: Frame) -> str:
        '''_summary_

        _extended_summary_

        :param frame: _description_
        :type frame: Frame
        :return: _description_
        :rtype: str
        '''        
        #AM-DIS:1|A1:3|AM-NEG:5|A2:6-10
        tokens = []
        if len(frame.get_arguments()) == 0:
            return "_"
        else:
            for arg in frame.get_arguments():
                name = arg.get_name()
                start = arg.get_start()
                end = arg.get_end()
                tokens.append(f'{name}:{start}-{end}')
            return '|'.join(tokens)

    def __recalculate_frames(self):
        '''_summary_

        _extended_summary_
        '''        
        for f in self._frames:
            pred_token_number = int(f.get_predicate().get_token())
            pred_sense = f.get_predicate().get_sense()
            pred_token = self.get_token(pred_token_number)
            pred_token.set_attribute(self.get_column_by_type(ColumnType.UP_PRED).get_name(), pred_sense)
            argheads_column = self.get_column_by_type(ColumnType.UP_ARGHEADS)
            argspans_column = self.get_column_by_type(ColumnType.UP_ARGSPANS)
            frame_column = self.get_column_by_type(ColumnType.UP_FRAME)
            if argheads_column:
                pred_token.set_attribute(self.get_column_by_type(ColumnType.UP_ARGHEADS).get_name(), self.__to_dep(f))
            if argspans_column:
                pred_token.set_attribute(self.get_column_by_type(ColumnType.UP_ARGSPANS).get_name(), self.__to_span(f))
            if frame_column:
                print("TO BE IMPLEMENTED")

    def to_conllup(self, definition: bool = False) -> str:
        '''_summary_

        _extended_summary_

        :param definition: _description_, defaults to False
        :type definition: bool, optional
        :return: _description_
        :rtype: str
        '''        
        buffer: List[str] = []
        if definition:
            buffer.append(f'# {self.get_columns_attribute()} = {" ".join(self.get_column_names())}')
        for m in self._metadata:
            v = self.get_metadata(m).get_value()
            if v is not None:
                buffer.append(f'# {m} = {v}')
            else:
                buffer.append(f'# {m}')
                
        self.__recalculate_frames()
        for t in self._tokens:
            attributes = []
            for d in self.get_column_names():
                attributes.append(str(self._tokens[t].get_attribute(d)))
            buffer.append("\t".join(attributes))
        return "\n".join(buffer)

    def to_json(self) -> dict:
        '''_summary_

        _extended_summary_

        :return: _description_
        :rtype: dist
        '''        
        obj = {
            "columns": self.get_column_names(),
            "metadata": {},
            "tokens": {}
        }
        for m in self._metadata:
            obj["metadata"][m] = self.get_metadata(m).get_value()
        self.__recalculate_frames()
        for t in self._tokens:
            attributes = {}
            for d in self.get_column_names():
                attributes[d] = str(self._tokens[t].get_attribute(d))
            obj["tokens"][t] = attributes
        return obj

    def __merge(self, span_arguments: List[Argument], dep_arguments: List[Argument]) -> List[Argument]:
        '''_summary_

        _extended_summary_

        :param span_arguments: _description_
        :type span_arguments: List[Argument]
        :param dep_arguments: _description_
        :type dep_arguments: List[Argument]
        :return: _description_
        :rtype: List[Argument]
        '''        
        arguments = []
        if span_arguments is None and dep_arguments is None:
            return arguments
        if span_arguments is None and dep_arguments is not None:
            return dep_arguments
        if span_arguments is not None and dep_arguments is None:
            return span_arguments
        for arg in zip(span_arguments, dep_arguments):
            argument = arg[0]
            argument.set_head(arg[1].get_head())
            arguments.append(argument)
        return arguments

    def parse_frames(self):
        '''_summary_

        _extended_summary_
        '''        
        predicate_column = self.get_column_by_type(ColumnType.UP_PRED)
        if predicate_column:
            depargs_column = self.get_column_by_type(ColumnType.UP_ARGHEADS)
            spanargs_column = self.get_column_by_type(ColumnType.UP_ARGSPANS)
            frame_column = self.get_column_by_type(ColumnType.UP_FRAME)
            depargs = None
            spanargs = None
            predicate_counter = 0
            for t in self._tokens:
                token = self._tokens[t]
                if token.get_attribute(predicate_column) != Token.get_empty():
                    predicate_value = token.get_attribute(predicate_column)
                    predicate_counter += 1
                    frame = Frame()
                    self.add_frame(frame)
                    frame.set_predicate(Predicate(predicate_value, token=token.get_id()))
                    if depargs_column or spanargs_column:
                        if depargs_column is not None:
                            depargs = token.get_attribute(depargs_column)
                        if spanargs_column is not None:
                            spanargs = token.get_attribute(spanargs_column)
                        if spanargs is not None and spanargs != Token.get_empty():
                            span_arguments = self.__parse_span(spanargs)
                        else:
                            span_arguments = None
                        if depargs is not None and depargs != Token.get_empty():
                            dep_arguments = self.__parse_dep(depargs)
                        else:
                            dep_arguments = None
                        #merge head pos with start/end pos
                        arguments = self.__merge(span_arguments, dep_arguments)
                        for argument in arguments:
                            frame.add_argument(argument)
                    elif frame_column:
                        frame_column = f'{ColumnType.UP_FRAME.value}{predicate_counter}'
                        for ft in self._tokens:
                            frame_token = self._tokens[ft]
                            attribute_value = frame_token.get_attribute(frame_column)
                            if attribute_value != Token.get_empty():
                                id = frame_token.get_id()
                                argument = Argument(attribute_value, id, id, id)
                                frame.add_argument(argument)

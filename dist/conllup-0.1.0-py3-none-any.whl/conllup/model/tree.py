from typing import List
from conllup.model.token import Token
from conllup.model.metadata import Metadata
from conllup.exception.model_exception import ModelException
from conllup.model.column import Column, ColumnType
from conllup.model.frame import Frame
from conllup.model.argument import Argument
from conllup.model.predicate import Predicate

COLUMNS_ATTRIBUTE = "global.columns"

COLUMNS_DEFAULT = [
    Column("ID"),
    Column("FORM"), 
    Column("LEMMA"),
    Column("UPOS"), 
    Column("XPOS"),
    Column("FEATS"),
    Column("HEAD"),
    Column("DEPREL"),
    Column("DEPS"),
    Column("MISC")
]

class Tree():

    def __init__(self, columns: List[Column] = None):
        if columns is None:
            self.columns = COLUMNS_DEFAULT
        else:
            self.columns = columns
        self.metadata = {}
        self.tokens = {}
        self.frames = []

    def set_columns(self, columns: List[Column]):
        self.columns = columns

    def set_columns_from_names(self, names):
        columns = []
        for name in names:
            type = self.get_type_from_name(name)
            columns.append(Column(name, type))
        self.columns = columns

    def get_type_from_name(self, name):
        for ct in ColumnType:
            if ct.value == name:
                return ct
        return ColumnType.BASIC

    def get_column_by_type(self, type):
        for c in self.columns:
            if c.get_type() == type:
                return c
        return None

    def get_frames(self):
        return self.frames

    def add_frame(self, frame):
        self.frames.append(frame)

    def get_column_names(self):
        names = []
        for column in self.columns:
            names.append(column.get_name())
        return names

    def get_columns_attribute(self):
        return COLUMNS_ATTRIBUTE

    def add_metadata(self, key, value = None):
        if key in self.metadata and key != self.get_columns_attribute():
            raise ModelException(f'Metadata {key} already exists')
        self.metadata[key] = Metadata()
        if value is not None:
            self.metadata[key].set_value(value)
        return self.metadata[key]

    def get_metadata(self, key):
        if key not in self.metadata:
            raise ModelException(f'Metadata {key} does not exist')
        return self.metadata[key]

    def add_token(self, key):
        if key in self.tokens:
            raise ModelException(f'Token {key} already created')
        self.tokens[key] = Token(self, key)
        column = self.get_column_by_type(ColumnType.ID)
        if column is not None:
            self.tokens[key].set_attribute(column.get_name(), key)
        return self.tokens[key]
    
    def get_token(self, key):
        if key not in self.tokens:
            raise ModelException(f'Token {key} does not exist')
        return self.tokens[key]

    def get_tokens(self):
        arr = []
        for token in self.tokens:
            arr.append(self.tokens[token])
        return arr

    def __parse_dep(self, text):
        #AM-DIS:1|A1:5|AM-TMP:12|A2:14
        arguments = []
        try:
            segments = text.split("|")
            for segment in segments:
                subsegments = segment.split(":")
                arg = subsegments[0]
                pos = subsegments[1]
                arguments.append(Argument(arg, head = pos))
        except:
            raise ModelException(f'Incorrect UP:DEPARGS definition: {text}')
        return arguments

    def __parse_span(self, text):
        #AM-DIS:1-3|A1:5-9|AM-TMP:12-12|A2:14-15
        arguments = []
        try:
            segments = text.split("|")
            for segment in segments:
                subsegments = segment.split(":")
                arg = subsegments[0]
                pos_segments = subsegments[1].split("-")
                arguments.append(Argument(arg, start = pos_segments[0], end = pos_segments[1]))
        except:
            raise ModelException(f'Incorrect UP:SPANARGS definition: {text}')
        return arguments

    def __to_dep(self, frame):
        #AM-DIS:1|A1:3|AM-NEG:5|A2:6
        tokens = []
        for arg in frame.get_arguments():
            name = arg.get_name()
            pos = arg.get_head()
            tokens.append(f'{name}:{pos}')
        return '|'.join(tokens)

    def __to_span(self, frame):
        #AM-DIS:1|A1:3|AM-NEG:5|A2:6-10
        tokens = []
        for arg in frame.get_arguments():
            name = arg.get_name()
            start = arg.get_start()
            end = arg.get_end()
            tokens.append(f'{name}:{start}-{end}')
        return '|'.join(tokens)

    def __recalculate_frames(self):
        for f in self.frames:
            pred_token_number = int(f.get_predicate().get_token())
            pred_sense = f.get_predicate().get_sense()
            pred_token = self.get_token(pred_token_number)
            pred_token.set_attribute(self.get_column_by_type(ColumnType.UP_PREDS).get_name(), pred_sense)
            pred_token.set_attribute(self.get_column_by_type(ColumnType.UP_DEPARGS).get_name(), self.__to_dep(f))
            pred_token.set_attribute(self.get_column_by_type(ColumnType.UP_SPANARGS).get_name(), self.__to_span(f))

    def to_conllup(self) -> str:
        buffer: List[str] = []
        buffer.append(f'# {self.get_columns_attribute()} = {" ".join(self.get_column_names())}')
        for m in self.metadata:
            buffer.append(f'# {m} = {self.get_metadata(m).get_value()}')
        self.__recalculate_frames()
        for t in self.tokens:
            attributes = []
            for d in self.get_column_names():
                attributes.append(str(self.tokens[t].get_attribute(d)))
            buffer.append("\t".join(attributes))
        return "\n".join(buffer)

    def to_json(self):
        obj = {
            "columns": self.get_column_names(),
            "metadata": {},
            "tokens": {}
        }
        for m in self.metadata:
            obj["metadata"][m] = self.get_metadata(m).get_value()
        self.__recalculate_frames()
        for t in self.tokens:
            attributes = {}
            for d in self.get_column_names():
                attributes[d] = str(self.tokens[t].get_attribute(d))
            obj["tokens"][t] = attributes
        return obj

    def __merge(self, span_arguments, dep_arguments):
        arguments = []
        if span_arguments is None and dep_arguments is None:
            return arguments
        if span_arguments is None and dep_arguments is not None:
            return dep_arguments
        if span_arguments is not None and dep_arguments is None:
            return span_arguments
        for arg in zip(span_arguments, dep_arguments):
            argument = arg[0]
            argument.set_head(arg[1].get_head())
            arguments.append(argument)
        return arguments

    def parse_frames(self):
        predicate_column = self.get_column_by_type(ColumnType.UP_PREDS)
        if predicate_column:
            depargs_column = self.get_column_by_type(ColumnType.UP_DEPARGS)
            spanargs_column = self.get_column_by_type(ColumnType.UP_SPANARGS)
            depargs = None
            spanargs = None
            for t in self.tokens:
                token = self.tokens[t]
                if token.get_attribute(predicate_column) != Token.get_empty():
                    predicate_value = token.get_attribute(predicate_column)
                    frame = Frame()
                    self.add_frame(frame)
                    frame.set_predicate(Predicate(predicate_value, token=token.get_id()))
                    if depargs_column is not None:
                        depargs = token.get_attribute(depargs_column)
                    if spanargs_column is not None:
                        spanargs = token.get_attribute(spanargs_column)
                    if spanargs is not None:
                        span_arguments = self.__parse_span(spanargs)
                    else:
                        span_arguments = None
                    if depargs is not None:
                        dep_arguments = self.__parse_dep(depargs)
                    else:
                        dep_arguments = None
                    #merge head pos with start/end pos
                    arguments = self.__merge(span_arguments, dep_arguments)
                    for argument in arguments:
                        frame.add_argument(argument)